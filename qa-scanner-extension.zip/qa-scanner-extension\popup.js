// popup.js

const toggle = document.getElementById('enableToggle');
const toggleLabel = document.getElementById('toggleLabel');
const statusBanner = document.getElementById('statusBanner');
const resultsArea = document.getElementById('resultsArea');
const noResults = document.getElementById('noResults');
const sendBtn = document.getElementById('sendBtn');
const confirmBox = document.getElementById('confirmBox');
const confirmDest = document.getElementById('confirmDest');
const btnConfirmSend = document.getElementById('btnConfirmSend');
const btnCancelSend = document.getElementById('btnCancelSend');
const sourceUrl = document.getElementById('sourceUrl');
const settingsLink = document.getElementById('settingsLink');

let currentResults = [];
let isAutoSend = false;

// Load saved state
chrome.storage.local.get(
  ['enabled', 'latestResults', 'latestUrl', 'phoneNumber', 'autoSend', 'lastSendStatus'],
  (data) => {
    const enabled = data.enabled || false;
    isAutoSend = data.autoSend || false;
    toggle.checked = enabled;
    updateToggleUI(enabled);
    updateSendUI(isAutoSend);

    if (data.lastSendStatus === 'success') {
      sendBtn.textContent = '✅ Auto-sent!';
      sendBtn.style.background = '#22c55e';
      chrome.storage.local.set({ lastSendStatus: null });
    }

    if (data.latestResults && data.latestResults.length > 0) {
      currentResults = data.latestResults;
      renderResults(data.latestResults);
      if (data.latestUrl) {
        sourceUrl.style.display = 'block';
        sourceUrl.textContent = '🌐 ' + data.latestUrl;
      }
      if (!isAutoSend) sendBtn.disabled = false;
    }
  }
);

toggle.addEventListener('change', () => {
  const enabled = toggle.checked;
  updateToggleUI(enabled);
  chrome.runtime.sendMessage({ type: 'TOGGLE', enabled });

  if (!enabled) {
    currentResults = [];
    renderResults([]);
    sendBtn.disabled = true;
    sourceUrl.style.display = 'none';
    chrome.storage.local.set({ latestResults: [], latestUrl: '' });
  }
});

function updateToggleUI(enabled) {
  toggleLabel.textContent = enabled ? 'ON' : 'OFF';
  if (enabled) {
    statusBanner.className = 'status-banner status-on';
    statusBanner.textContent = isAutoSend
      ? '✅ Scanner ON — Auto-send enabled (no confirmation needed)'
      : '✅ Scanner ON — Manual send (you confirm before sending)';
  } else {
    statusBanner.className = 'status-banner status-off';
    statusBanner.textContent = '⏸ Scanner is OFF — toggle to enable';
  }
}

function updateSendUI(autoSend) {
  if (autoSend) {
    sendBtn.textContent = '📤 Auto-send is ON';
    sendBtn.disabled = true;
    sendBtn.style.background = '#334155';
    sendBtn.style.color = '#94a3b8';
    confirmBox.style.display = 'none';
  } else {
    sendBtn.textContent = '📱 Send to Phone';
    sendBtn.style.background = '';
    sendBtn.style.color = '';
  }
}

function renderResults(results) {
  const cards = resultsArea.querySelectorAll('.qa-card');
  cards.forEach(c => c.remove());
  noResults.style.display = results.length === 0 ? 'block' : 'none';

  results.forEach((item, i) => {
    const card = document.createElement('div');
    card.className = 'qa-card';
    card.innerHTML = `
      <div class="qa-label">Question ${i + 1}</div>
      <div class="qa-q">${escapeHtml(item.question)}</div>
      <div class="qa-label" style="margin-top:6px;">Answer</div>
      <div class="qa-a">${escapeHtml(item.answer)}</div>
    `;
    resultsArea.appendChild(card);
  });
}

// Manual send — show confirmation dialog first
sendBtn.addEventListener('click', () => {
  if (isAutoSend) return;

  chrome.storage.local.get(['phoneNumber', 'twilioSid'], (data) => {
    if (!data.phoneNumber || !data.twilioSid) {
      alert('⚠️ Please configure your phone number and Twilio settings first.');
      return;
    }
    confirmDest.textContent = `📲 Sending to: ${data.phoneNumber}`;
    confirmBox.style.display = 'block';
    sendBtn.disabled = true;
  });
});

btnConfirmSend.addEventListener('click', () => {
  confirmBox.style.display = 'none';
  chrome.runtime.sendMessage({ type: 'SEND_SMS' }, (res) => {
    sendBtn.textContent = '✅ Sent!';
    sendBtn.style.background = '#22c55e';
    setTimeout(() => {
      sendBtn.textContent = '📱 Send to Phone';
      sendBtn.style.background = '';
      sendBtn.disabled = false;
    }, 3000);
  });
});

btnCancelSend.addEventListener('click', () => {
  confirmBox.style.display = 'none';
  sendBtn.disabled = false;
});

settingsLink.addEventListener('click', () => {
  chrome.runtime.openOptionsPage();
});

function escapeHtml(str) {
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
