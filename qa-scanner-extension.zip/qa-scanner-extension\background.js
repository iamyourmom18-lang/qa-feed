// background.js — service worker

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({
    enabled: false,
    phoneNumber: '',
    twilioSid: '',
    twilioToken: '',
    twilioFrom: '',
    autoSend: false
  });
  updateIcon(false);
});

function updateIcon(enabled) {
  chrome.action.setTitle({ title: enabled ? 'Q&A Scanner (ON)' : 'Q&A Scanner (OFF)' });
  chrome.action.setBadgeText({ text: enabled ? 'ON' : '' });
  chrome.action.setBadgeBackgroundColor({ color: enabled ? '#22c55e' : '#6b7280' });
}

function sendSMS(results, url, config) {
  if (!config.twilioSid || !config.twilioToken || !config.phoneNumber || !config.twilioFrom) return;

  let message = `Q&A SCAN RESULTS\nFrom: ${url}\n\n`;
  results.forEach((item, i) => {
    message += `Q${i + 1}: ${item.question}\nA: ${item.answer}\n\n`;
  });

  const body = new URLSearchParams({
    To: config.phoneNumber,
    From: config.twilioFrom,
    Body: message.trim()
  });

  fetch(`https://api.twilio.com/2010-04-01/Accounts/${config.twilioSid}/Messages.json`, {
    method: 'POST',
    headers: {
      'Authorization': 'Basic ' + btoa(`${config.twilioSid}:${config.twilioToken}`),
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: body.toString()
  })
  .then(res => res.json())
  .then(result => {
    if (result.sid) {
      // Signal popup to show success if open
      chrome.storage.local.set({ lastSendStatus: 'success' });
    } else {
      chrome.storage.local.set({ lastSendStatus: 'failed' });
    }
  })
  .catch(() => {
    chrome.storage.local.set({ lastSendStatus: 'failed' });
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'QUESTIONS_FOUND') {
    chrome.storage.local.get(
      ['enabled', 'autoSend', 'phoneNumber', 'twilioSid', 'twilioToken', 'twilioFrom'],
      (data) => {
        if (!data.enabled) return;

        // Store results for popup
        chrome.storage.local.set({ latestResults: msg.results, latestUrl: msg.url });

        if (data.autoSend) {
          // Auto-send immediately — no confirmation needed
          chrome.action.setBadgeText({ text: '📤' });
          chrome.action.setBadgeBackgroundColor({ color: '#22c55e' });
          sendSMS(msg.results, msg.url, data);
        } else {
          // Manual mode — show count badge, wait for user to open popup
          chrome.action.setBadgeText({ text: String(msg.count) });
          chrome.action.setBadgeBackgroundColor({ color: '#f59e0b' });
        }
      }
    );
  }

  if (msg.type === 'TOGGLE') {
    const enabled = msg.enabled;
    chrome.storage.local.set({ enabled });
    updateIcon(enabled);
  }

  // Popup requesting SMS send manually
  if (msg.type === 'SEND_SMS') {
    chrome.storage.local.get(
      ['phoneNumber', 'twilioSid', 'twilioToken', 'twilioFrom', 'latestResults', 'latestUrl'],
      (data) => {
        sendSMS(data.latestResults || [], data.latestUrl || '', data);
        sendResponse({ ok: true });
      }
    );
    return true; // keep channel open for async response
  }
});
