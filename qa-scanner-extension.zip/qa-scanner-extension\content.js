// content.js — runs on every page
// Scans for questions and reports back to background

(function () {
  // Only run if extension is enabled
  chrome.storage.local.get(['enabled'], (data) => {
    if (!data.enabled) return;
    scanPage();
  });

  function scanPage() {
    const text = document.body.innerText;
    const lines = text.split('\n').map(l => l.trim()).filter(l => l.length > 5);

    // Detect questions: lines ending in ? or starting with common question words
    const questionPattern = /(\?$|^(what|who|when|where|why|how|which|is|are|was|were|do|does|did|can|could|should|would|will)\b)/i;
    const questions = lines.filter(line => questionPattern.test(line) && line.length < 300);

    if (questions.length === 0) return;

    // Build Q&A pairs — look for text near the question as a likely answer
    const results = questions.slice(0, 20).map(q => {
      // Find the question in the page and grab the next non-empty line as candidate answer
      const idx = lines.indexOf(q);
      let answer = 'No answer found on page';
      for (let i = idx + 1; i < Math.min(idx + 5, lines.length); i++) {
        if (lines[i] && !questionPattern.test(lines[i]) && lines[i].length > 10) {
          answer = lines[i];
          break;
        }
      }
      return { question: q, answer };
    });

    chrome.runtime.sendMessage({
      type: 'QUESTIONS_FOUND',
      count: results.length,
      results,
      url: window.location.href
    });
  }
})();
