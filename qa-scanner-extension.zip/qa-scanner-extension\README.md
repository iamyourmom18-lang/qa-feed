# Q&A Scanner Browser Extension

Scans pages for questions in the background, displays them in a popup with detected answers, and lets you send them to your phone via SMS — with full user confirmation at every step.

## Install on Chrome / Arc / Brave (macOS)

1. Open your browser and go to: `chrome://extensions`
2. Enable **Developer Mode** (top right toggle)
3. Click **"Load unpacked"**
4. Select the `qa-scanner-extension` folder
5. The extension icon will appear in your toolbar

## First-Time Setup

1. Click the extension icon → click **"Configure phone number & SMS settings"**
2. Fill in:
   - **Your phone number** — where SMS results go (format: +15551234567)
   - **Twilio Account SID** — from twilio.com/console
   - **Twilio Auth Token** — from twilio.com/console
   - **Twilio From Number** — your Twilio phone number
3. Click **Save Settings**

> Twilio has a free tier. Sign up at twilio.com — you get a free phone number and trial credits.

## How to Use

1. Click the extension icon
2. Toggle the switch to **ON** — the banner turns green
3. Open any page — the extension scans it in the background
4. When questions are found, the badge shows the count (e.g. "3")
5. Click the icon to see all Q&A pairs
6. Review them, then click **"Send to Phone"**
7. A confirmation dialog appears — click **"Yes, Send"** to confirm

## Turn Off

Click the icon → toggle switch to **OFF**. Scanning stops immediately and results are cleared.

## Files

- `manifest.json` — extension config
- `background.js` — service worker, manages on/off state
- `content.js` — runs on each page, detects questions
- `popup.html/js` — the UI you see when you click the icon
- `options.html/js` — settings page for phone/Twilio config

## Icons

Add 3 PNG icon files to an `icons/` folder:
- `icons/icon16.png` (16x16)
- `icons/icon48.png` (48x48)
- `icons/icon128.png` (128x128)

You can use any emoji-to-PNG converter or just use a simple magnifying glass icon.
