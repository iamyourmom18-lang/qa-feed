// Load saved settings
chrome.storage.local.get(['phoneNumber', 'twilioSid', 'twilioToken', 'twilioFrom', 'autoSend'], (data) => {
  document.getElementById('phoneNumber').value = data.phoneNumber || '';
  document.getElementById('twilioSid').value = data.twilioSid || '';
  document.getElementById('twilioToken').value = data.twilioToken || '';
  document.getElementById('twilioFrom').value = data.twilioFrom || '';
  document.getElementById('autoSendToggle').checked = data.autoSend || false;
});

document.getElementById('saveBtn').addEventListener('click', () => {
  const settings = {
    phoneNumber: document.getElementById('phoneNumber').value.trim(),
    twilioSid:   document.getElementById('twilioSid').value.trim(),
    twilioToken: document.getElementById('twilioToken').value.trim(),
    twilioFrom:  document.getElementById('twilioFrom').value.trim(),
    autoSend:    document.getElementById('autoSendToggle').checked
  };
  chrome.storage.local.set(settings, () => {
    const msg = document.getElementById('savedMsg');
    msg.style.display = 'block';
    setTimeout(() => msg.style.display = 'none', 3000);
  });
});
